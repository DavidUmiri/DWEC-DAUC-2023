function suma(n1,n2)
{
    let resultado = n1+n2;
    resultado=parseInt(resultado);
    document.getElementById("c4").innerHTML=resultado;
    return resultado;
}




    
