function perimetroRectangulo(a,b)
{
    let resultado=(a+b)*2;
    resultado=parseFloat(resultado);
    return resultado;
}
