function esPrimo(n1)
{
    if(n1%2!=0 && n1%3!=0 &&n1%5!=0 && n1&7!=0 )
    {
        return true;
    }
    else{
        return false;
    }
}