console.log("Esto es una prueba externa");
